# This file was automatically created by FeynRules 2.3.32
# Mathematica version: 11.1.1 for Mac OS X x86 (64-bit) (April 18, 2017)
# Date: Tue 10 Apr 2018 11:28:05


from object_library import all_decays, Decay
import particles as P


Decay_h = Decay(name = 'Decay_h',
                particle = P.h,
                partial_widths = {(P.b,P.b__tilde__):'(((-24*mB**4*yb**2)/v**2 + (6*mB**2*mH**2*yb**2)/v**2)*cmath.sqrt(-4*mB**2*mH**2 + mH**4))/(16.*cmath.pi*abs(mH)**3)',
                                  (P.ta__minus__,P.ta__plus__):'(((2*mH**2*mTau**2*ytau**2)/v**2 - (8*mTau**4*ytau**2)/v**2)*cmath.sqrt(mH**4 - 4*mH**2*mTau**2))/(16.*cmath.pi*abs(mH)**3)',
                                  (P.t,P.t__tilde__):'(((6*mH**2*mT**2*yt**2)/v**2 - (24*mT**4*yt**2)/v**2)*cmath.sqrt(mH**4 - 4*mH**2*mT**2))/(16.*cmath.pi*abs(mH)**3)',
                                  (P.W__minus__,P.W__plus__):'(((cw**2*mH**4)/v**2 - (4*cw**2*mH**2*mW**2)/v**2 + (12*cw**2*mW**4)/v**2)*cmath.sqrt(mH**4 - 4*mH**2*mW**2))/(16.*cmath.pi*abs(mH)**3)',
                                  (P.Z,P.Z):'(((cz**2*mH**4)/v**2 - (4*cz**2*mH**2*mZ**2)/v**2 + (12*cz**2*mZ**4)/v**2)*cmath.sqrt(mH**4 - 4*mH**2*mZ**2))/(32.*cmath.pi*abs(mH)**3)'})

Decay_W__plus__ = Decay(name = 'Decay_W__plus__',
                        particle = P.W__plus__,
                        partial_widths = {(P.c,P.s__tilde__):'(gL**2*mW**4)/(16.*cmath.pi*abs(mW)**3)',
                                          (P.t,P.b__tilde__):'(((-3*gL**2*mB**2)/2. - (3*gL**2*mT**2)/2. - (3*gL**2*mB**4)/(2.*mW**2) + (3*gL**2*mB**2*mT**2)/mW**2 - (3*gL**2*mT**4)/(2.*mW**2) + 3*gL**2*mW**2)*cmath.sqrt(mB**4 - 2*mB**2*mT**2 + mT**4 - 2*mB**2*mW**2 - 2*mT**2*mW**2 + mW**4))/(48.*cmath.pi*abs(mW)**3)',
                                          (P.u,P.d__tilde__):'(gL**2*mW**4)/(16.*cmath.pi*abs(mW)**3)',
                                          (P.ve,P.e__plus__):'(gL**2*mW**4)/(48.*cmath.pi*abs(mW)**3)',
                                          (P.vm,P.mu__plus__):'(gL**2*mW**4)/(48.*cmath.pi*abs(mW)**3)',
                                          (P.vt,P.ta__plus__):'((-mTau**2 + mW**2)*(-(gL**2*mTau**2)/2. - (gL**2*mTau**4)/(2.*mW**2) + gL**2*mW**2))/(48.*cmath.pi*abs(mW)**3)'})

Decay_b = Decay(name = 'Decay_b',
                particle = P.b,
                partial_widths = {(P.W__minus__,P.t):'(((3*gL**2*mB**2)/2. + (3*gL**2*mT**2)/2. + (3*gL**2*mB**4)/(2.*mW**2) - (3*gL**2*mB**2*mT**2)/mW**2 + (3*gL**2*mT**4)/(2.*mW**2) - 3*gL**2*mW**2)*cmath.sqrt(mB**4 - 2*mB**2*mT**2 + mT**4 - 2*mB**2*mW**2 - 2*mT**2*mW**2 + mW**4))/(96.*cmath.pi*abs(mB)**3)'})

Decay_ta__minus__ = Decay(name = 'Decay_ta__minus__',
                          particle = P.ta__minus__,
                          partial_widths = {(P.W__minus__,P.vt):'((mTau**2 - mW**2)*((gL**2*mTau**2)/2. + (gL**2*mTau**4)/(2.*mW**2) - gL**2*mW**2))/(32.*cmath.pi*abs(mTau)**3)'})

Decay_t = Decay(name = 'Decay_t',
                particle = P.t,
                partial_widths = {(P.W__plus__,P.b):'(((3*gL**2*mB**2)/2. + (3*gL**2*mT**2)/2. + (3*gL**2*mB**4)/(2.*mW**2) - (3*gL**2*mB**2*mT**2)/mW**2 + (3*gL**2*mT**4)/(2.*mW**2) - 3*gL**2*mW**2)*cmath.sqrt(mB**4 - 2*mB**2*mT**2 + mT**4 - 2*mB**2*mW**2 - 2*mT**2*mW**2 + mW**4))/(96.*cmath.pi*abs(mT)**3)'})

Decay_Z = Decay(name = 'Decay_Z',
                particle = P.Z,
                partial_widths = {(P.b,P.b__tilde__):'(((-3*gL**4*mB**2)/(2.*(gL**2 + gY**2)) - (7*gL**2*gY**2*mB**2)/(gL**2 + gY**2) - (17*gY**4*mB**2)/(6.*(gL**2 + gY**2)) + (3*gL**4*mZ**2)/(2.*(gL**2 + gY**2)) + (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (5*gY**4*mZ**2)/(6.*(gL**2 + gY**2)))*cmath.sqrt(-4*mB**2*mZ**2 + mZ**4))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.c,P.c__tilde__):'(mZ**2*((3*gL**4*mZ**2)/(2.*(gL**2 + gY**2)) - (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (17*gY**4*mZ**2)/(6.*(gL**2 + gY**2))))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.d,P.d__tilde__):'(mZ**2*((3*gL**4*mZ**2)/(2.*(gL**2 + gY**2)) + (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (5*gY**4*mZ**2)/(6.*(gL**2 + gY**2))))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.e__minus__,P.e__plus__):'(mZ**2*((gL**4*mZ**2)/(2.*(gL**2 + gY**2)) - (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (5*gY**4*mZ**2)/(2.*(gL**2 + gY**2))))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.mu__minus__,P.mu__plus__):'(mZ**2*((gL**4*mZ**2)/(2.*(gL**2 + gY**2)) - (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (5*gY**4*mZ**2)/(2.*(gL**2 + gY**2))))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.s,P.s__tilde__):'(mZ**2*((3*gL**4*mZ**2)/(2.*(gL**2 + gY**2)) + (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (5*gY**4*mZ**2)/(6.*(gL**2 + gY**2))))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.ta__minus__,P.ta__plus__):'((-(gL**4*mTau**2)/(2.*(gL**2 + gY**2)) - (5*gL**2*gY**2*mTau**2)/(gL**2 + gY**2) + (7*gY**4*mTau**2)/(2.*(gL**2 + gY**2)) + (gL**4*mZ**2)/(2.*(gL**2 + gY**2)) - (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (5*gY**4*mZ**2)/(2.*(gL**2 + gY**2)))*cmath.sqrt(-4*mTau**2*mZ**2 + mZ**4))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.t,P.t__tilde__):'(((-3*gL**4*mT**2)/(2.*(gL**2 + gY**2)) - (11*gL**2*gY**2*mT**2)/(gL**2 + gY**2) + (7*gY**4*mT**2)/(6.*(gL**2 + gY**2)) + (3*gL**4*mZ**2)/(2.*(gL**2 + gY**2)) - (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (17*gY**4*mZ**2)/(6.*(gL**2 + gY**2)))*cmath.sqrt(-4*mT**2*mZ**2 + mZ**4))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.u,P.u__tilde__):'(mZ**2*((3*gL**4*mZ**2)/(2.*(gL**2 + gY**2)) - (gL**2*gY**2*mZ**2)/(gL**2 + gY**2) + (17*gY**4*mZ**2)/(6.*(gL**2 + gY**2))))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.ve,P.ve__tilde__):'(mZ**2*((gL**2*mZ**2)/2. + (gY**2*mZ**2)/2.))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.vm,P.vm__tilde__):'(mZ**2*((gL**2*mZ**2)/2. + (gY**2*mZ**2)/2.))/(48.*cmath.pi*abs(mZ)**3)',
                                  (P.vt,P.vt__tilde__):'(mZ**2*((gL**2*mZ**2)/2. + (gY**2*mZ**2)/2.))/(48.*cmath.pi*abs(mZ)**3)'})

