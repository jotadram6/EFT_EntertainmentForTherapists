# This file was automatically created by FeynRules 2.3.32
# Mathematica version: 11.1.1 for Mac OS X x86 (64-bit) (April 18, 2017)
# Date: Tue 10 Apr 2018 11:28:05



from object_library import all_parameters, Parameter


from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# User-defined parameters.
cplq1111 = Parameter(name = 'cplq1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = '\\text{cplq1111}',
                     lhablock = 'FF',
                     lhacode = [ 1 ])

clq1111 = Parameter(name = 'clq1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{clq1111}',
                    lhablock = 'FF',
                    lhacode = [ 2 ])

clu1111 = Parameter(name = 'clu1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{clu1111}',
                    lhablock = 'FF',
                    lhacode = [ 3 ])

cld1111 = Parameter(name = 'cld1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cld1111}',
                    lhablock = 'FF',
                    lhacode = [ 4 ])

ceq1111 = Parameter(name = 'ceq1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ceq1111}',
                    lhablock = 'FF',
                    lhacode = [ 5 ])

ceu1111 = Parameter(name = 'ceu1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ceu1111}',
                    lhablock = 'FF',
                    lhacode = [ 6 ])

ced1111 = Parameter(name = 'ced1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ced1111}',
                    lhablock = 'FF',
                    lhacode = [ 7 ])

clequ1111 = Parameter(name = 'clequ1111',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{clequ1111}',
                      lhablock = 'FF',
                      lhacode = [ 8 ])

cledq1111 = Parameter(name = 'cledq1111',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{cledq1111}',
                      lhablock = 'FF',
                      lhacode = [ 9 ])

cplequ1111 = Parameter(name = 'cplequ1111',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{cplequ1111}',
                       lhablock = 'FF',
                       lhacode = [ 10 ])

cplq2211 = Parameter(name = 'cplq2211',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = '\\text{cplq2211}',
                     lhablock = 'FF',
                     lhacode = [ 11 ])

clq2211 = Parameter(name = 'clq2211',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{clq2211}',
                    lhablock = 'FF',
                    lhacode = [ 12 ])

clu2211 = Parameter(name = 'clu2211',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{clu2211}',
                    lhablock = 'FF',
                    lhacode = [ 13 ])

cld2211 = Parameter(name = 'cld2211',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cld2211}',
                    lhablock = 'FF',
                    lhacode = [ 14 ])

ceq2211 = Parameter(name = 'ceq2211',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ceq2211}',
                    lhablock = 'FF',
                    lhacode = [ 15 ])

ceu2211 = Parameter(name = 'ceu2211',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ceu2211}',
                    lhablock = 'FF',
                    lhacode = [ 16 ])

ced2211 = Parameter(name = 'ced2211',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ced2211}',
                    lhablock = 'FF',
                    lhacode = [ 17 ])

clequ2211 = Parameter(name = 'clequ2211',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{clequ2211}',
                      lhablock = 'FF',
                      lhacode = [ 18 ])

cledq2211 = Parameter(name = 'cledq2211',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{cledq2211}',
                      lhablock = 'FF',
                      lhacode = [ 19 ])

cplequ2211 = Parameter(name = 'cplequ2211',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{cplequ2211}',
                       lhablock = 'FF',
                       lhacode = [ 20 ])

cplq3311 = Parameter(name = 'cplq3311',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = '\\text{cplq3311}',
                     lhablock = 'FF',
                     lhacode = [ 21 ])

clq3311 = Parameter(name = 'clq3311',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{clq3311}',
                    lhablock = 'FF',
                    lhacode = [ 22 ])

clu3311 = Parameter(name = 'clu3311',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{clu3311}',
                    lhablock = 'FF',
                    lhacode = [ 23 ])

cld3311 = Parameter(name = 'cld3311',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cld3311}',
                    lhablock = 'FF',
                    lhacode = [ 24 ])

ceq3311 = Parameter(name = 'ceq3311',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ceq3311}',
                    lhablock = 'FF',
                    lhacode = [ 25 ])

ceu3311 = Parameter(name = 'ceu3311',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ceu3311}',
                    lhablock = 'FF',
                    lhacode = [ 26 ])

ced3311 = Parameter(name = 'ced3311',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ced3311}',
                    lhablock = 'FF',
                    lhacode = [ 27 ])

clequ3311 = Parameter(name = 'clequ3311',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{clequ3311}',
                      lhablock = 'FF',
                      lhacode = [ 28 ])

cledq3311 = Parameter(name = 'cledq3311',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{cledq3311}',
                      lhablock = 'FF',
                      lhacode = [ 29 ])

cplequ3311 = Parameter(name = 'cplequ3311',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{cplequ3311}',
                       lhablock = 'FF',
                       lhacode = [ 30 ])

cll1111 = Parameter(name = 'cll1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cll1111}',
                    lhablock = 'FF',
                    lhacode = [ 31 ])

cle1111 = Parameter(name = 'cle1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cle1111}',
                    lhablock = 'FF',
                    lhacode = [ 32 ])

cee1111 = Parameter(name = 'cee1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cee1111}',
                    lhablock = 'FF',
                    lhacode = [ 33 ])

cll1122 = Parameter(name = 'cll1122',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cll1122}',
                    lhablock = 'FF',
                    lhacode = [ 34 ])

cle1122 = Parameter(name = 'cle1122',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cle1122}',
                    lhablock = 'FF',
                    lhacode = [ 35 ])

cle2211 = Parameter(name = 'cle2211',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cle2211}',
                    lhablock = 'FF',
                    lhacode = [ 36 ])

cee1122 = Parameter(name = 'cee1122',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cee1122}',
                    lhablock = 'FF',
                    lhacode = [ 37 ])

cll2222 = Parameter(name = 'cll2222',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cll2222}',
                    lhablock = 'FF',
                    lhacode = [ 38 ])

cle2222 = Parameter(name = 'cle2222',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cle2222}',
                    lhablock = 'FF',
                    lhacode = [ 39 ])

cee2222 = Parameter(name = 'cee2222',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cee2222}',
                    lhablock = 'FF',
                    lhacode = [ 40 ])

cll3333 = Parameter(name = 'cll3333',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cll3333}',
                    lhablock = 'FF',
                    lhacode = [ 41 ])

cle3333 = Parameter(name = 'cle3333',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cle3333}',
                    lhablock = 'FF',
                    lhacode = [ 42 ])

cee3333 = Parameter(name = 'cee3333',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{cee3333}',
                    lhablock = 'FF',
                    lhacode = [ 43 ])

cw = Parameter(name = 'cw',
               nature = 'external',
               type = 'real',
               value = 1,
               texname = '\\text{cw}',
               lhablock = 'Higgs1SM',
               lhacode = [ 1 ])

cz = Parameter(name = 'cz',
               nature = 'external',
               type = 'real',
               value = 1,
               texname = '\\text{cz}',
               lhablock = 'Higgs1SM',
               lhacode = [ 2 ])

yt = Parameter(name = 'yt',
               nature = 'external',
               type = 'real',
               value = 1,
               texname = 'y_t',
               lhablock = 'Higgs1SM',
               lhacode = [ 3 ])

yb = Parameter(name = 'yb',
               nature = 'external',
               type = 'real',
               value = 1,
               texname = 'y_b',
               lhablock = 'Higgs1SM',
               lhacode = [ 4 ])

ytau = Parameter(name = 'ytau',
                 nature = 'external',
                 type = 'real',
                 value = 1,
                 texname = 'y_{\\tau }',
                 lhablock = 'Higgs1SM',
                 lhacode = [ 5 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 127.9,
                  texname = '\\text{aEWM1}',
                  lhablock = 'SMINPUTS',
                  lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.0000116637,
               texname = 'G_f',
               lhablock = 'SMINPUTS',
               lhacode = [ 2 ])

aS = Parameter(name = 'aS',
               nature = 'external',
               type = 'real',
               value = 0.1184,
               texname = '\\text{aS}',
               lhablock = 'SMINPUTS',
               lhacode = [ 3 ])

gs = Parameter(name = 'gs',
               nature = 'external',
               type = 'real',
               value = 1.21362,
               texname = 'g_s',
               lhablock = 'SMINPUTS',
               lhacode = [ 4 ])

gL = Parameter(name = 'gL',
               nature = 'external',
               type = 'real',
               value = 0.648455,
               texname = 'g_L',
               lhablock = 'SMINPUTS',
               lhacode = [ 5 ])

gY = Parameter(name = 'gY',
               nature = 'external',
               type = 'real',
               value = 0.357971,
               texname = 'g_Y',
               lhablock = 'SMINPUTS',
               lhacode = [ 6 ])

v = Parameter(name = 'v',
              nature = 'external',
              type = 'real',
              value = 246.221,
              texname = 'v',
              lhablock = 'SMINPUTS',
              lhacode = [ 7 ])

mTau = Parameter(name = 'mTau',
                 nature = 'external',
                 type = 'real',
                 value = 1.777,
                 texname = '\\text{mTau}',
                 lhablock = 'MASS',
                 lhacode = [ 15 ])

mT = Parameter(name = 'mT',
               nature = 'external',
               type = 'real',
               value = 173.2,
               texname = '\\text{mT}',
               lhablock = 'MASS',
               lhacode = [ 6 ])

mB = Parameter(name = 'mB',
               nature = 'external',
               type = 'real',
               value = 5.1,
               texname = '\\text{mB}',
               lhablock = 'MASS',
               lhacode = [ 5 ])

mZ = Parameter(name = 'mZ',
               nature = 'external',
               type = 'real',
               value = 91.1875,
               texname = '\\text{mZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

mW = Parameter(name = 'mW',
               nature = 'external',
               type = 'real',
               value = 79.8312,
               texname = '\\text{mW}',
               lhablock = 'MASS',
               lhacode = [ 24 ])

mH = Parameter(name = 'mH',
               nature = 'external',
               type = 'real',
               value = 125.09,
               texname = '\\text{mH}',
               lhablock = 'MASS',
               lhacode = [ 25 ])

WT = Parameter(name = 'WT',
               nature = 'external',
               type = 'real',
               value = 1.50833649,
               texname = '\\text{WT}',
               lhablock = 'DECAY',
               lhacode = [ 6 ])

WZ = Parameter(name = 'WZ',
               nature = 'external',
               type = 'real',
               value = 2.4952,
               texname = '\\text{WZ}',
               lhablock = 'DECAY',
               lhacode = [ 23 ])

WW = Parameter(name = 'WW',
               nature = 'external',
               type = 'real',
               value = 2.085,
               texname = '\\text{WW}',
               lhablock = 'DECAY',
               lhacode = [ 24 ])

WH = Parameter(name = 'WH',
               nature = 'external',
               type = 'real',
               value = 0.004,
               texname = '\\text{WH}',
               lhablock = 'DECAY',
               lhacode = [ 25 ])

aEW = Parameter(name = 'aEW',
                nature = 'internal',
                type = 'real',
                value = '1/aEWM1',
                texname = '\\text{aEW}')

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '(gL*gY)/cmath.sqrt(gL**2 + gY**2)',
               texname = '\\text{ee}')

cosw = Parameter(name = 'cosw',
                 nature = 'internal',
                 type = 'real',
                 value = 'gL/cmath.sqrt(gL**2 + gY**2)',
                 texname = '\\cos _w')

sinw = Parameter(name = 'sinw',
                 nature = 'internal',
                 type = 'real',
                 value = 'gY/cmath.sqrt(gL**2 + gY**2)',
                 texname = '\\sin _w')

